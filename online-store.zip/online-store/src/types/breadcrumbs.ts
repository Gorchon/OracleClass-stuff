export interface BreadcrumbEntry {
  name: string;
  path: string;
}

export interface BreadcrumbsProps {
  entries: BreadcrumbEntry[];
}
